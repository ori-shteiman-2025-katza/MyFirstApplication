package com.orisht.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class gameActivity extends AppCompatActivity {
    EditText firstnum, secondnum, yournum;
     RadioGroup rangeRadioGroup;
     Button okBtn;
     EditText yourNumEditText;
     TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        initViews();
    }
    private void initViews() {
        RadioGroup rangeRadioGroup = findViewById(R.id.rangeRadioGroup);
        Button okBtn = findViewById(R.id.okBtn);
        EditText yourNumEditText = findViewById(R.id.yournum);
        TextView resultTextView = findViewById(R.id.result);
    }
okBtn.
        @Override
        public void onClick(View v) {
            // קבלת הבחירה מהרדיו גרופ
            int selectedId = rangeRadioGroup.getCheckedRadioButtonId();

            // הגדרת משתנים לשמירת הטווחים
            int min = 0, max = 0;

            // קביעת הטווח בהתאם לבחירה
            switch (selectedId) {
                case R.id.range1to10:
                    min = 1;
                    max = 10;
                    break;
                case R.id.range10to100:
                    min = 10;
                    max = 100;
                    break;
                case R.id.range100to1000:
                    min = 100;
                    max = 1000;
                    break;
                default:
                    resultTextView.setText("Please select a range!");
                    return;
            }

            // קבלת המספר שהוזן מה-EditText
            String input = yourNumEditText.getText().toString();

            // בדיקת אם הוזן מספר
            if (input.isEmpty()) {
                resultTextView.setText("Please enter a number!");
                return;
            }

            // המרת הקלט למספר
            int yourNum = Integer.parseInt(input);

            // בדיקת אם המספר נמצא בטווח שנבחר
            if (yourNum >= min && yourNum <= max) {
                resultTextView.setText("Your number is in the range: " + yourNum);
            } else {
                resultTextView.setText("Number is out of range!");
            }
        }
    });
}
}

    //private void initViews() {
        // Initialize the EditText, Button, and TextView
        //firstnum = findViewById(R.id.firstnum);
        //secondnum = findViewById(R.id.secondnum);
        //yournum = findViewById(R.id.yournum);
        //ok = findViewById(R.id.okbtn);
        //result = findViewById(R.id.result);

        // Button for generating a random number
        //send = findViewById(R.id.numbtn);
        //send.setOnClickListener(new View.OnClickListener() {
            @Override
            //public void onClick(View view) {
                // Get first and second numbers
                //int first = Integer.parseInt(firstnum.getText().toString());
                //int second = Integer.parseInt(secondnum.getText().toString());

                // Generate a random number between first and second
                //gamenum = (int) (Math.random() * ((second - first) + 1)) + first;
                //count = 0; // Reset count
           // }
        //});

        // Button for checking the user's guess
        //ok.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {
                //int your = Integer.parseInt(yournum.getText().toString());
                //count++; // Increment the number of tries

                // Check if the guess is correct
                //if (your == gamenum) {
                    result.setText("Correct! You won in " + count + " tries.");
               // } else if (your > gamenum) {
                  //  result.setText("Wrong. The number is too big.");
                //} else {
                  //  result.setText("Wrong. The number is too small.");
               // }
           // }
        //});
    }
}